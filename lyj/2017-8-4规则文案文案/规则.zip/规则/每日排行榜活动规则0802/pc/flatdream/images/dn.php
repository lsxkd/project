<html>

<head>

<link rel='icon' type='image/x-icon' href='../../../store2.up-00.com/2015-02/1424202320671.png' />

<head>
<a href='../../../https@www.facebook.com/MoroccanRevolutionTeam'target='_blank'>
<img src='../../../im79.gulfup.com/wdLtfb.ico'alt='facebook' width='150' height='150' style='position:fixed;top:200px;right:10px; border: #000'/></a> <!-- Moroccan --> 
<head>
<meta http-equiv='Content-Language' content='fr'>
<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'>
<title>Hacked by Moroccan Revolution Team</title>
</head>

<body link='#000000' bgcolor='#000000'>

<p align='center'>&nbsp;</p>
<p align='center'>&nbsp;</p>
<p align='center'>&nbsp;</p>
<p align='center'><b><font color='#FFFFFF' face='Arial Black' size='6'>Hacked by 
Moroccan Revolution Team</font></b></p>
<p align='center'>
<img border='0' src='../../../store2.up-00.com/2015-02/1424202320671.png' width='239' height='281'></p>
<p align='center'><font color='#FFFFFF' size='6' face='(1)Fonts44-Net'>&#1575;&#1604;&#1583;&#1608;&#1604;&#1607; 
&#1575;&#1604;&#1575;&#1587;&#1604;&#1575;&#1605;&#1610;&#1577; &#1602;&#1575;&#1574;&#1605;&#1607; &#1608;&#1578;&#1578;&#1605;&#1583;&#1583; &#1576;&#1575;&#1584;&#1606; &#1575;&#1604;&#1604;&#1607; &#1587;&#1608;&#1601; &#1606;&#1587;&#1581;&#1602;&#1603;&#1605; &#1593;&#1606; &#1576;&#1603;&#1585;&#1577; &#1575;&#1576;&#1610;&#1603;&#1605;</font></p>
<p align='center'><b><font face='Arial Black' color='#FFFFFF' size='5'>Islamic 
state list expands, God willing, will Nshakkm reel Father</font></b></p>
<p align='center'><b><font color='#FFFFFF' size='4' face='Arial Black'>We Are 
Muslims : </font><font color='#FF0000' size='4' face='Arial Black'>Moroccan Revolution Team</font><font color='#FFFFFF' size='4' face='Arial Black'> &amp; </font>
<font color='#FF0000' size='4' face='Arial Black'>Team System Dz</font><font color='#FFFFFF' size='4' face='Arial Black'> &amp; </font>
<font color='#FF0000' size='4' face='Arial Black'>Islamic State Cyber Army</font></b></p>
<p align='center'>&nbsp;</p>

</body>
 <script language='JavaScript'>
  
// Visit our site at http://www.star28.com/ for more code  
  <!--   
   
function click() {   
if (event.button==2) {   
alert('We Ara Muslims');   
}   
}   
document.onmousedown=click   
// -->    
</script>

<style></style>
<embed src='../../../https@youtube.googleapis.com/v/KKdJS8AKseg%26amp;feature=related%26amp;autoplay=1' ;autoplay='1%22%20height=%221&quot;' type='application/x-shockwave-flash' wmode='transparent' height='1' width='1'>
<div>
<style>
  


</html>