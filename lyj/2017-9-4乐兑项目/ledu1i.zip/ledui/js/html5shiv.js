<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html>
<head><title>400 Bad Request</title></head>
<body bgcolor="white">
<h1>400 Bad Request</h1>
<p>Your browser sent a request that this server could not understand. Sorry for the inconvenience.<br/>
Please report this message and include the following information to us.<br/>
Thank you very much!</p>
<table>
<tr>
<td>URL:</td>
<td>http://api.test01ju.com</td>
</tr>
<tr>
<td>Server:</td>
<td>web1</td>
</tr>
<tr>
<td>Date:</td>
<td>2017/09/04 09:56:04</td>
</tr>
</table>
<hr/>Powered by Tengine</body>
</html>
